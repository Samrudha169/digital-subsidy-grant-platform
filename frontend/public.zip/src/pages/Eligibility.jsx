import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Eligibility.css";

const Eligibility = () => {
    const [formData, setFormData] = useState({
        state: "",
        ageGroup: "",
        occupation: "",
        category: "",
        incomeGroup: "",
    });

    const [schemes, setSchemes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [searched, setSearched] = useState(false);

    // States list
    const states = [
        "Andhra Pradesh",
        "Arunachal Pradesh",
        "Assam",
        "Bihar",
        "Chhattisgarh",
        "Goa",
        "Gujarat",
        "Haryana",
        "Himachal Pradesh",
        "Jharkhand",
        "Karnataka",
        "Kerala",
        "Madhya Pradesh",
        "Maharashtra",
        "Manipur",
        "Meghalaya",
        "Mizoram",
        "Nagaland",
        "Odisha",
        "Punjab",
        "Rajasthan",
        "Sikkim",
        "Tamil Nadu",
        "Telangana",
        "Tripura",
        "Uttar Pradesh",
        "Uttarakhand",
        "West Bengal",
        "Andaman and Nicobar Islands",
        "Chandigarh",
        "Dadra and Nagar Haveli and Daman and Diu",
        "Delhi",
        "Jammu and Kashmir",
        "Ladakh",
        "Lakshadweep",
        "Puducherry"
    ];

    // Age Groups
    const ageGroups = [
        { label: "Below 18", value: 16 },
        { label: "18 - 25", value: 22 },
        { label: "26 - 35", value: 30 },
        { label: "36 - 45", value: 40 },
        { label: "46 - 60", value: 50 },
        { label: "Above 60", value: 65 }
    ];

    // Occupation Options
    const occupations = [
        "Farmer",
        "Student",
        "Entrepreneur",
        "Small Business Owner",
        "Other"
    ];

    // Social Categories
    const categories = [
        "GENERAL",
        "OBC",
        "SC",
        "ST"
    ];

    // Income Groups
    const incomeGroups = [
        { label: "Below ₹1 Lakh", value: 50000 },
        { label: "₹1 - ₹3 Lakhs", value: 200000 },
        { label: "₹3 - ₹5 Lakhs", value: 400000 },
        { label: "₹5 - ₹8 Lakhs", value: 650000 },
        { label: "Above ₹8 Lakhs", value: 1000000 }
    ];

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleReset = () => {
        setFormData({
            state: "",
            ageGroup: "",
            occupation: "",
            category: "",
            incomeGroup: "",
        });

        setSchemes([]);
        setError("");
        setSearched(false);
    };

    /*
     * Converts the scheme name returned by the backend
     * into the correct React route.
     */
    const getSchemePath = (schemeName) => {
        if (!schemeName) {
            return "/schemes";
        }

        const name = schemeName.toLowerCase();

        if (name.includes("pm-kisan") || name.includes("pm kisan")) {
            return "/schemes/pm-kisan";
        }

        if (
            name.includes("national scholarship") ||
            name.includes("nsp") ||
            name.includes("scholarship portal")
        ) {
            return "/schemes/nsp";
        }

        if (name.includes("pmegp")) {
            return "/schemes/pmegp";
        }

        // If no matching detail page exists
        // send the user to the schemes page.
        return "/schemes";
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        setLoading(true);
        setError("");
        setSearched(true);

        // Find selected age value
        const selectedAgeGroup = ageGroups.find(
            (g) => g.label === formData.ageGroup
        );

        // Find selected income value
        const selectedIncomeGroup = incomeGroups.find(
            (g) => g.label === formData.incomeGroup
        );

        // Payload expected by backend
        const payload = {
            state: formData.state,
            age: selectedAgeGroup
                ? selectedAgeGroup.value
                : null,
            occupation: formData.occupation,
            category: formData.category,
            annualIncome: selectedIncomeGroup
                ? selectedIncomeGroup.value
                : null,
        };

        console.log("Eligibility Request:", payload);

        try {
            const response = await fetch(
                "http://localhost:8080/api/v1/eligibility/check",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(payload),
                }
            );

            if (!response.ok) {
                throw new Error(
                    "Failed to fetch eligible schemes. Server error."
                );
            }

            const data = await response.json();

            console.log("Eligible Schemes:", data);

            setSchemes(data);

        } catch (err) {
            console.error("Error fetching schemes:", err);

            setError(
                "Unable to connect to the backend server. Please make sure Spring Boot is running."
            );

            setSchemes([]);

        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="eligibility-page">

            {/* ================= HERO ================= */}

            <div className="eligibility-hero">

                <div className="eligibility-hero-content">

                    <h1>
                        Scheme Eligibility
                    </h1>

                    <p>
                        Enter your details to find government schemes
                        you may be eligible for.
                    </p>

                </div>

            </div>


            {/* ================= MAIN CONTAINER ================= */}

            <div className="eligibility-container">

                {/* ================= FORM CARD ================= */}

                <div className="eligibility-card">

                    <h2 className="form-heading">
                        Check Your Eligibility
                    </h2>

                    <p className="form-subheading">
                        Provide your details below to discover suitable
                        government schemes.
                    </p>


                    <form onSubmit={handleSubmit}>

                        <div className="eligibility-form-grid">

                            {/* STATE */}

                            <div className="eligibility-form-group">

                                <label>
                                    State / Union Territory
                                </label>

                                <select
                                    name="state"
                                    value={formData.state}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select State
                                    </option>

                                    {states.map((st, idx) => (

                                        <option
                                            key={idx}
                                            value={st}
                                        >
                                            {st}
                                        </option>

                                    ))}

                                </select>

                            </div>


                            {/* AGE */}

                            <div className="eligibility-form-group">

                                <label>
                                    Age Group
                                </label>

                                <select
                                    name="ageGroup"
                                    value={formData.ageGroup}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select Age Group
                                    </option>

                                    {ageGroups.map((ag, idx) => (

                                        <option
                                            key={idx}
                                            value={ag.label}
                                        >
                                            {ag.label}
                                        </option>

                                    ))}

                                </select>

                            </div>


                            {/* OCCUPATION */}

                            <div className="eligibility-form-group">

                                <label>
                                    Occupation / Status
                                </label>

                                <select
                                    name="occupation"
                                    value={formData.occupation}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select your occupation
                                    </option>

                                    {occupations.map((occ, idx) => (

                                        <option
                                            key={idx}
                                            value={occ}
                                        >
                                            {occ}
                                        </option>

                                    ))}

                                </select>

                            </div>


                            {/* CATEGORY */}

                            <div className="eligibility-form-group">

                                <label>
                                    Social Category
                                </label>

                                <select
                                    name="category"
                                    value={formData.category}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select Category
                                    </option>

                                    {categories.map((cat, idx) => (

                                        <option
                                            key={idx}
                                            value={cat}
                                        >
                                            {cat}
                                        </option>

                                    ))}

                                </select>

                            </div>


                            {/* INCOME */}

                            <div className="eligibility-form-group">

                                <label>
                                    Annual Family Income
                                </label>

                                <select
                                    name="incomeGroup"
                                    value={formData.incomeGroup}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select Income Group
                                    </option>

                                    {incomeGroups.map((inc, idx) => (

                                        <option
                                            key={idx}
                                            value={inc.label}
                                        >
                                            {inc.label}
                                        </option>

                                    ))}

                                </select>

                            </div>

                        </div>


                        {/* BUTTONS */}

                        <div className="eligibility-actions">

                            <button
                                type="submit"
                                className="eligibility-submit"
                                disabled={loading}
                            >

                                {loading
                                    ? "Searching..."
                                    : "Find Eligible Schemes"}

                            </button>


                            <button
                                type="button"
                                className="eligibility-reset"
                                onClick={handleReset}
                            >
                                Reset
                            </button>

                        </div>

                    </form>


                    {/* ERROR */}

                    {error && (

                        <div className="eligibility-error">
                            {error}
                        </div>

                    )}

                </div>


                {/* ================= RESULTS ================= */}

                {searched && (

                    <div className="eligibility-results">

                        <h3 className="results-heading">

                            {loading
                                ? "Finding Eligible Schemes..."
                                : schemes.length > 0
                                    ? `Eligible Schemes (${schemes.length})`
                                    : "No Eligible Schemes Found"}

                        </h3>


                        {/* SCHEME CARDS */}

                        {!loading && schemes.length > 0 && (

                            <div className="eligibility-results-grid">

                                {schemes.map((scheme) => (

                                    <div
                                        key={scheme.schemeId}
                                        className="eligibility-scheme-card"
                                    >

                                        {/* CARD HEADER */}

                                        <div className="result-card-header">

                                            <span className="result-category">
                                                Government Scheme
                                            </span>

                                            <span className="result-target">
                                                Score: {scheme.eligibilityScore}
                                            </span>

                                        </div>


                                        {/* SCHEME NAME */}

                                        <h4>
                                            {scheme.schemeName}
                                        </h4>


                                        {/* DESCRIPTION */}

                                        <p>
                                            {scheme.description}
                                        </p>


                                        {/* VIEW DETAILS */}

                                        <Link
                                            to={getSchemePath(
                                                scheme.schemeName
                                            )}
                                            className="result-button"
                                        >
                                            View Details
                                        </Link>

                                    </div>

                                ))}

                            </div>

                        )}


                        {/* NO RESULTS */}

                        {!loading && schemes.length === 0 && (

                            <div className="no-schemes">

                                <p>
                                    Based on your selections, no schemes
                                    currently match your eligibility
                                    parameters.
                                </p>

                            </div>

                        )}

                    </div>

                )}

            </div>

        </div>
    );
};

export default Eligibility;