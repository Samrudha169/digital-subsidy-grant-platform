import { Link } from 'react-router-dom';
import { useState } from 'react';
import '../App.css';

function Home() {

    const [searchTerm, setSearchTerm] = useState('');

    // =========================================================
    // ELIGIBILITY FORM STATE
    // =========================================================

    const [eligibilityData, setEligibilityData] = useState({
        state: '',
        ageGroup: '',
        occupation: '',
        category: '',
        incomeGroup: ''
    });

    const [eligibleSchemes, setEligibleSchemes] = useState([]);
    const [eligibilityLoading, setEligibilityLoading] = useState(false);
    const [eligibilityError, setEligibilityError] = useState('');
    const [eligibilitySearched, setEligibilitySearched] = useState(false);


    // =========================================================
    // AGE GROUPS
    // Same mapping used in Eligibility.jsx
    // =========================================================

    const ageGroups = [
        { label: 'Below 18', value: 16 },
        { label: '18 - 25', value: 22 },
        { label: '26 - 35', value: 30 },
        { label: '36 - 45', value: 40 },
        { label: '46 - 60', value: 50 },
        { label: 'Above 60', value: 65 }
    ];


    // =========================================================
    // INCOME GROUPS
    // Same mapping used in Eligibility.jsx
    // =========================================================

    const incomeGroups = [
        { label: 'Below ₹1 Lakh', value: 50000 },
        { label: '₹1 - ₹3 Lakhs', value: 200000 },
        { label: '₹3 - ₹5 Lakhs', value: 400000 },
        { label: '₹5 - ₹8 Lakhs', value: 650000 },
        { label: 'Above ₹8 Lakhs', value: 1000000 }
    ];


    // =========================================================
    // SEARCH
    // =========================================================

    const handleSearch = (e) => {
        e.preventDefault();

        if (searchTerm.trim() !== '') {
            window.location.href =
                `/schemes?search=${encodeURIComponent(searchTerm.trim())}`;
        }
    };


    // =========================================================
    // ELIGIBILITY FORM CHANGE
    // =========================================================

    const handleEligibilityChange = (e) => {
        const { name, value } = e.target;

        setEligibilityData((prev) => ({
            ...prev,
            [name]: value
        }));
    };


    // =========================================================
    // FIND ELIGIBLE SCHEMES
    // =========================================================

    const handleEligibilitySubmit = async (e) => {
        e.preventDefault();

        setEligibilityLoading(true);
        setEligibilityError('');
        setEligibilitySearched(true);
        setEligibleSchemes([]);

        // Find numeric age from selected age group
        const selectedAgeGroup = ageGroups.find(
            (group) => group.label === eligibilityData.ageGroup
        );

        // Find numeric income from selected income group
        const selectedIncomeGroup = incomeGroups.find(
            (group) => group.label === eligibilityData.incomeGroup
        );


        // =====================================================
        // PAYLOAD SENT TO SPRING BOOT
        // =====================================================

        const payload = {
            state: eligibilityData.state,

            age: selectedAgeGroup
                ? selectedAgeGroup.value
                : null,

            occupation: eligibilityData.occupation,

            category: eligibilityData.category,

            annualIncome: selectedIncomeGroup
                ? selectedIncomeGroup.value
                : null
        };


        console.log('Eligibility request:', payload);


        try {

            const response = await fetch(
                'http://localhost:8080/api/v1/eligibility/check',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type': 'application/json'
                    },

                    body: JSON.stringify(payload)
                }
            );


            if (!response.ok) {
                throw new Error(
                    'Failed to fetch eligible schemes'
                );
            }


            const data = await response.json();


            console.log('Eligible schemes:', data);


            // Store backend response
            setEligibleSchemes(data);


        } catch (error) {

            console.error(
                'Error fetching eligible schemes:',
                error
            );

            setEligibilityError(
                'Unable to connect to the backend server. Please make sure Spring Boot is running.'
            );

            setEligibleSchemes([]);

        } finally {

            setEligibilityLoading(false);

        }
    };


    // =========================================================
    // DATA
    // =========================================================

    const stats = [
        { value: '3', label: 'Featured Schemes' },
        { value: '3', label: 'Focus Sectors' },
        { value: 'One', label: 'Unified Platform' },
        { value: '4-Step', label: 'Application Process' }
    ];


    const categories = [
        {
            id: 1,
            name: 'Agriculture',
            description:
                'Financial assistance and support schemes for farmers and agricultural workers',
            count: '1 Scheme Available'
        },
        {
            id: 2,
            name: 'Education',
            description:
                'Scholarships and educational grants for students from all backgrounds',
            count: '1 Scheme Available'
        },
        {
            id: 3,
            name: 'Business & Entrepreneurship',
            description:
                'Support for entrepreneurs and small business development initiatives',
            count: '1 Scheme Available'
        }
    ];


    const featuredSchemes = [
        {
            id: 1,
            name: 'PM-KISAN',
            category: 'Agriculture',
            target: 'Farmers',
            description:
                'Income support scheme providing ₹6,000 per year to eligible farmer families in three equal installments.',
            path: '/schemes/pm-kisan'
        },
        {
            id: 2,
            name: 'National Scholarship Portal (NSP)',
            category: 'Education',
            target: 'Students',
            description:
                'Centralized platform offering various scholarships for students from pre-matric to post-matric levels.',
            path: '/schemes/nsp'
        },
        {
            id: 3,
            name: 'PMEGP',
            category: 'Business & Entrepreneurship',
            target: 'Entrepreneurs',
            description:
                'Credit-linked subsidy scheme for generating self-employment through establishment of micro-enterprises.',
            path: '/schemes/pmegp'
        }
    ];


    const steps = [
        {
            number: '01',
            title: 'Discover',
            description:
                'Browse and search for government schemes relevant to your needs and profile'
        },
        {
            number: '02',
            title: 'Check Eligibility',
            description:
                'Verify your eligibility using our comprehensive criteria matching system'
        },
        {
            number: '03',
            title: 'Apply',
            description:
                'Submit your application with required documents through our guided process'
        },
        {
            number: '04',
            title: 'Track',
            description:
                'Monitor your application status and receive updates at every stage'
        }
    ];


    // =========================================================
    // RETURN
    // =========================================================

    return (
        <div className="dsgp-app">

            <main>

                {/* =================================================
                    HERO
                ================================================= */}

                <section className="hero">

                    <div className="hero-content">

                        <h2 className="hero-title">
                            Find Government Schemes You're Eligible For
                        </h2>

                        <p className="hero-description">
                            DSGP is your unified platform to discover, understand,
                            apply for, and track government subsidies and grants.
                            Access financial assistance schemes designed for
                            farmers, students, entrepreneurs, and citizens across India.
                        </p>

                        <form
                            className="hero-search"
                            onSubmit={handleSearch}
                        >

                            <input
                                type="text"
                                className="search-input"
                                value={searchTerm}
                                onChange={(e) =>
                                    setSearchTerm(e.target.value)
                                }
                                placeholder="Search for schemes by name, category, or keyword..."
                                aria-label="Search for schemes"
                            />

                        </form>

                        <div className="hero-actions">

                            <Link
                                to="/schemes"
                                className="btn btn-primary"
                            >
                                Explore Schemes
                            </Link>

                            <Link
                                to="/eligibility"
                                className="btn btn-secondary"
                            >
                                Check Eligibility
                            </Link>

                        </div>

                    </div>

                </section>


                {/* =================================================
                    STATISTICS
                ================================================= */}

                <section className="stats">

                    <div className="stats-container">

                        {stats.map((stat, index) => (

                            <div
                                key={index}
                                className="stat-card"
                            >

                                <div className="stat-value">
                                    {stat.value}
                                </div>

                                <div className="stat-label">
                                    {stat.label}
                                </div>

                            </div>

                        ))}

                    </div>

                </section>


                {/* =================================================
                    FOCUS SECTORS
                ================================================= */}

                <section className="categories">

                    <div>

                        <div className="section-header">

                            <h2 className="section-title">
                                Focus Sectors
                            </h2>

                            <p className="section-subtitle">
                                Explore schemes organized by key sectors to
                                find assistance programs relevant to your field
                            </p>

                        </div>


                        <div className="categories-grid">

                            {categories.map((category) => (

                                <div
                                    key={category.id}
                                    className="category-card"
                                >

                                    <h3 className="category-name">
                                        {category.name}
                                    </h3>

                                    <p className="category-description">
                                        {category.description}
                                    </p>

                                    <span className="category-count">
                                        {category.count}
                                    </span>

                                </div>

                            ))}

                        </div>

                    </div>

                </section>


                {/* =================================================
                    FEATURED SCHEMES
                ================================================= */}

                <section className="featured-schemes">

                    <div>

                        <div className="section-header">

                            <h2 className="section-title">
                                Featured Schemes
                            </h2>

                            <p className="section-subtitle">
                                Explore our curated selection of major
                                government assistance programs
                            </p>

                        </div>


                        <div className="schemes-grid">

                            {featuredSchemes.map((scheme) => (

                                <div
                                    key={scheme.id}
                                    className="scheme-card"
                                >

                                    <div className="scheme-header">

                                        <span className="scheme-badge">
                                            {scheme.category}
                                        </span>

                                        <span className="scheme-target">
                                            {scheme.target}
                                        </span>

                                    </div>


                                    <h3 className="scheme-name">
                                        {scheme.name}
                                    </h3>


                                    <p className="scheme-description">
                                        {scheme.description}
                                    </p>


                                    <Link
                                        to={scheme.path}
                                        className="btn btn-primary scheme-card-button"
                                    >
                                        View Details
                                    </Link>

                                </div>

                            ))}

                        </div>

                    </div>

                </section>


                {/* =================================================
                    ELIGIBILITY FINDER
                ================================================= */}

                <section className="eligibility-finder">

                    <div>

                        <div className="section-header">

                            <h2 className="section-title">
                                Check Your Eligibility
                            </h2>

                            <p className="section-subtitle">
                                Answer a few questions to discover schemes
                                you may qualify for
                            </p>

                        </div>


                        <form
                            className="eligibility-form"
                            onSubmit={handleEligibilitySubmit}
                        >

                            {/* STATE */}

                            <div className="form-group">

                                <label htmlFor="state">
                                    State / Union Territory
                                </label>

                                <select
                                    id="state"
                                    name="state"
                                    className="form-control"
                                    value={eligibilityData.state}
                                    onChange={handleEligibilityChange}
                                    required
                                >

                                    <option value="" disabled>
                                        Select your state
                                    </option>

                                    <option value="Andhra Pradesh">
                                        Andhra Pradesh
                                    </option>

                                    <option value="Karnataka">
                                        Karnataka
                                    </option>

                                    <option value="Maharashtra">
                                        Maharashtra
                                    </option>

                                    <option value="Tamil Nadu">
                                        Tamil Nadu
                                    </option>

                                    <option value="Delhi">
                                        Delhi
                                    </option>

                                    <option value="Other">
                                        Other
                                    </option>

                                </select>

                            </div>


                            {/* AGE */}

                            <div className="form-group">

                                <label htmlFor="age">
                                    Age Group
                                </label>

                                <select
                                    id="age"
                                    name="ageGroup"
                                    className="form-control"
                                    value={eligibilityData.ageGroup}
                                    onChange={handleEligibilityChange}
                                    required
                                >

                                    <option value="" disabled>
                                        Select your age group
                                    </option>

                                    <option value="Below 18">
                                        Below 18
                                    </option>

                                    <option value="18 - 25">
                                        18 - 25
                                    </option>

                                    <option value="26 - 35">
                                        26 - 35
                                    </option>

                                    <option value="36 - 45">
                                        36 - 45
                                    </option>

                                    <option value="46 - 60">
                                        46 - 60
                                    </option>

                                    <option value="Above 60">
                                        Above 60
                                    </option>

                                </select>

                            </div>


                            {/* OCCUPATION */}

                            <div className="form-group">

                                <label htmlFor="occupation">
                                    Occupation / Status
                                </label>

                                <select
                                    id="occupation"
                                    name="occupation"
                                    className="form-control"
                                    value={eligibilityData.occupation}
                                    onChange={handleEligibilityChange}
                                    required
                                >

                                    <option value="" disabled>
                                        Select your occupation
                                    </option>

                                    <option value="Farmer">
                                        Farmer
                                    </option>

                                    <option value="Student">
                                        Student
                                    </option>

                                    <option value="Entrepreneur">
                                        Entrepreneur
                                    </option>

                                    <option value="Small Business Owner">
                                        Small Business Owner
                                    </option>

                                    <option value="Other">
                                        Other
                                    </option>

                                </select>

                            </div>


                            {/* SOCIAL CATEGORY */}

                            <div className="form-group">

                                <label htmlFor="category">
                                    Social Category
                                </label>

                                <select
                                    id="category"
                                    name="category"
                                    className="form-control"
                                    value={eligibilityData.category}
                                    onChange={handleEligibilityChange}
                                    required
                                >

                                    <option value="" disabled>
                                        Select your category
                                    </option>

                                    <option value="GENERAL">
                                        General
                                    </option>

                                    <option value="OBC">
                                        OBC
                                    </option>

                                    <option value="SC">
                                        SC
                                    </option>

                                    <option value="ST">
                                        ST
                                    </option>

                                </select>

                            </div>


                            {/* ANNUAL INCOME */}

                            <div className="form-group">

                                <label htmlFor="incomeGroup">
                                    Annual Family Income
                                </label>

                                <select
                                    id="incomeGroup"
                                    name="incomeGroup"
                                    className="form-control"
                                    value={eligibilityData.incomeGroup}
                                    onChange={handleEligibilityChange}
                                    required
                                >

                                    <option value="" disabled>
                                        Select your income group
                                    </option>

                                    <option value="Below ₹1 Lakh">
                                        Below ₹1 Lakh
                                    </option>

                                    <option value="₹1 - ₹3 Lakhs">
                                        ₹1 - ₹3 Lakhs
                                    </option>

                                    <option value="₹3 - ₹5 Lakhs">
                                        ₹3 - ₹5 Lakhs
                                    </option>

                                    <option value="₹5 - ₹8 Lakhs">
                                        ₹5 - ₹8 Lakhs
                                    </option>

                                    <option value="Above ₹8 Lakhs">
                                        Above ₹8 Lakhs
                                    </option>

                                </select>

                            </div>


                            {/* SUBMIT */}

                            <button
                                type="submit"
                                className="btn btn-primary form-submit"
                                disabled={eligibilityLoading}
                            >

                                {eligibilityLoading
                                    ? 'Searching...'
                                    : 'Find Eligible Schemes'}

                            </button>

                        </form>


                        {/* ERROR */}

                        {eligibilityError && (

                            <div className="eligibility-error">

                                {eligibilityError}

                            </div>

                        )}


                        {/* =================================================
                            ELIGIBILITY RESULTS
                        ================================================= */}

                        {eligibilitySearched && !eligibilityLoading && (

                            <div className="eligibility-results">

                                <h3 className="results-heading">

                                    {eligibleSchemes.length > 0
                                        ? `Eligible Schemes (${eligibleSchemes.length})`
                                        : 'No Eligible Schemes Found'}

                                </h3>


                                {eligibleSchemes.length > 0 ? (

                                    <div className="eligibility-results-grid">

                                        {eligibleSchemes.map((scheme) => (

                                            <div
                                                key={scheme.schemeId}
                                                className="eligibility-scheme-card"
                                            >

                                                <div className="result-card-header">

                                                    <span className="result-category">
                                                        Government Scheme
                                                    </span>

                                                    <span className="result-target">
                                                        Score: {scheme.eligibilityScore}
                                                    </span>

                                                </div>


                                                <h4>
                                                    {scheme.schemeName}
                                                </h4>


                                                <p>
                                                    {scheme.description}
                                                </p>


                                                <Link
                                                    to="/schemes"
                                                    className="result-button"
                                                >
                                                    View Details
                                                </Link>

                                            </div>

                                        ))}

                                    </div>

                                ) : (

                                    <div className="no-schemes">

                                        <p>
                                            Based on your selections, no schemes
                                            currently match your eligibility parameters.
                                        </p>

                                    </div>

                                )}

                            </div>

                        )}

                    </div>

                </section>


                {/* =================================================
                    APPLICATION TRACKING
                ================================================= */}

                <section className="tracking-section">

                    <div>

                        <div className="section-header">

                            <h2 className="section-title">
                                Track Your Application
                            </h2>

                            <p className="section-subtitle">
                                Enter your application ID to check the current
                                status of your submission
                            </p>

                        </div>


                        <form
                            className="tracking-form"
                            onSubmit={(e) => e.preventDefault()}
                        >

                            <input
                                type="text"
                                className="tracking-input"
                                placeholder="Enter Application ID (e.g., DSGP2024001234)"
                                aria-label="Application ID"
                            />

                            <button
                                type="submit"
                                className="btn btn-primary"
                            >
                                Track Status
                            </button>

                        </form>

                    </div>

                </section>


                {/* =================================================
                    HOW IT WORKS
                ================================================= */}

                <section className="how-it-works">

                    <div>

                        <div className="section-header">

                            <h2 className="section-title">
                                How DSGP Works
                            </h2>

                            <p className="section-subtitle">
                                A simple four-step process to access government
                                assistance programs
                            </p>

                        </div>


                        <div className="steps-grid">

                            {steps.map((step, index) => (

                                <div
                                    key={index}
                                    className="step-card"
                                >

                                    <div className="step-number">
                                        {step.number}
                                    </div>

                                    <h3 className="step-title">
                                        {step.title}
                                    </h3>

                                    <p className="step-description">
                                        {step.description}
                                    </p>

                                </div>

                            ))}

                        </div>

                    </div>

                </section>

            </main>


            {/* =================================================
                FOOTER
            ================================================= */}

            <footer className="footer">

                <div className="footer-container">

                    <div className="footer-info">

                        <div className="footer-brand">

                            <h3>
                                Digital Subsidy & Grant Platform
                            </h3>

                            <p>
                                DSGP is an academic demonstration project
                                designed to showcase a unified digital platform
                                for accessing government subsidy and grant schemes.
                            </p>

                            <p className="footer-disclaimer">

                                <strong>Disclaimer:</strong> This is an
                                educational project. For official scheme
                                information and applications, please visit the
                                respective government portals and verify all
                                details through authorized channels.

                            </p>

                        </div>


                        <div className="footer-links">

                            <h4>Quick Links</h4>

                            <Link to="/">Home</Link>
                            <Link to="/schemes">Find Schemes</Link>
                            <Link to="/eligibility">Check Eligibility</Link>
                            <Link to="/track">Track Application</Link>
                            <Link to="/about">About DSGP</Link>

                        </div>


                        <div className="footer-links">

                            <h4>Resources</h4>

                            <Link to="/help">Help & Support</Link>
                            <Link to="/faq">FAQs</Link>
                            <Link to="/contact">Contact Us</Link>
                            <Link to="/privacy">Privacy Policy</Link>
                            <Link to="/terms">Terms of Service</Link>

                        </div>

                    </div>


                    <div className="footer-bottom">

                        <p>
                            &copy; 2024 Digital Subsidy & Grant Platform
                            (DSGP) - Academic Project
                        </p>

                    </div>

                </div>

            </footer>

        </div>
    );
}

export default Home;