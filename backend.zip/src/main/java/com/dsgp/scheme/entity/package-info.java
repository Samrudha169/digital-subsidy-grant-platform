/**
 * Scheme JPA entities.
 * <p><strong>Phase:</strong> Architecture setup — no implementation yet.
 */
package com.dsgp.scheme.entity;
